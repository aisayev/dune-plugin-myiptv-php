<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/default_dune_plugin_fw.php';

require 'myiptv_plugin.php';

//////////////////////////////////////////////////////////////////////////

function throw_m3u_error()
{
    throw new DuneException(
        'M3U access error', 0,
        ActionFactory::show_error(
            true,
            'Ошибка M3U',
            array(
                'Не возможно загрузить M3U-Файл.',
                'Проверьте правильность настроек и переинициализируйте',
		'Dune-HD GUI ("stanby" или "power off/on").')));
}
///////////////////////////////////////////////////////////////////////////

DefaultDunePluginFw::$plugin_class_name = 'DemoPlugin';

///////////////////////////////////////////////////////////////////////////
?>
