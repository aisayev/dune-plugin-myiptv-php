<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/hashed_array.php';
require_once 'lib/tv/abstract_tv.php';
require_once 'lib/tv/default_epg_item.php';

require_once 'myiptv_channel.php';

///////////////////////////////////////////////////////////////////////////

class DemoM3uTv extends AbstractTv
{
    public function __construct()
    {
        parent::__construct(
            AbstractTv::MODE_CHANNELS_N_TO_M,
            DemoConfig::TV_FAVORITES_SUPPORTED,
            false);
    }

    public function get_fav_icon_url()
    {
        return DemoConfig::FAV_CHANNEL_GROUP_ICON_PATH;
    }

    public function get_tv_stream_url($playback_url, &$plugin_cookies)
    {
	if ($plugin_cookies->use_proxy == 'yes') 
	    $url = str_replace('udp://@', 'http://ts://'.$plugin_cookies->proxy_ip.':'.$plugin_cookies->proxy_port.'/udp/', $playback_url);
	else
	    $url = $playback_url;

	return $url;
    }


    ///////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////

    private static function get_icon_path($channel_id)
    { 
	$channel_id = ($channel_id < 1000) ? $channel_id : 0;
	return sprintf(DemoConfig::M3U_ICON_FILE_URL_FORMAT, $channel_id); 
    }

    private static function get_future_epg_days($channel_id)
    { 
	$days = ($channel_id < 1000) ? 1 : 0;
	return $days;
    }

    ///////////////////////////////////////////////////////////////////////

    protected function load_channels(&$plugin_cookies)
    {
        $this->channels = new HashedArray();
        $this->groups = new HashedArray();

        if ($this->is_favorites_supported())
        {
            $this->groups->put(
                new FavoritesGroup(
                    $this,
                    '__favorites',
                    DemoConfig::FAV_CHANNEL_GROUP_CAPTION,
                    DemoConfig::FAV_CHANNEL_GROUP_ICON_PATH));
        }

        $all_channels_group = 
            new AllChannelsGroup(
                $this,
                DemoConfig::ALL_CHANNEL_GROUP_CAPTION,
                DemoConfig::ALL_CHANNEL_GROUP_ICON_PATH);

        $this->groups->put($all_channels_group);

	$out_lines = "";
	$channels_id_parsed = array();
	$m3u_lines = array();
	
	  
	try {
		$doc = HD::http_get_document(DemoConfig::M3U_ID_FILE_URL);
	}
	catch (Exception $e) {
		hd_print("Can't fetch myiptv_chennels_id, local copy used.");		
		$doc = file_get_contents(dirname(__FILE__).'/data/myiptv_channels_id');
	}
	    
    	$channels_id_parsed = unserialize($doc);

        $m3u = isset($plugin_cookies->m3u) ? $plugin_cookies->m3u : '';

	if ($m3u == '') {
            $m3u = dirname(__FILE__).'/m3u/default.m3u';
    	    hd_print("Loading default M3U: $m3u");
        }
	else if (strtolower(substr($m3u, 0, 7)) == "http://") 
    	    hd_print("Loading HTTP M3U: $m3u");
    	else { 
	    $m3u = "/D/".$m3u;
    	    hd_print("Loading local file M3U: $m3u");
	}

        if (!($m3u_lines = file($m3u, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))) 
		throw_m3u_error();


        for ($i = 0; $i < count($m3u_lines); ++$i)
        {
            if (preg_match('/^#EXTINF:[^,]+,(.+)$/', $m3u_lines[$i], $matches) != 1)
                continue;

            $caption = $matches[1];

            if ($i + 1 >= count($m3u_lines))
                break;

            $media_url = null;

            for (++$i; $i < count($m3u_lines); ++$i)
            {
                if (preg_match('/^udp:\/\//', strtolower($m3u_lines[$i])) == 1)
                {
                    $media_url = $m3u_lines[$i];
                    break;
                }
            	else if (preg_match('/^http:\/\//', strtolower($m3u_lines[$i])) == 1)
                {
                    $media_url = $m3u_lines[$i];
                    break;
                }
	
	    }

            if (is_null($media_url))
                break;
            
            $id_key = md5(strtolower(str_replace(array("\r", "\n", "\"", " "), '', $caption)));
            
            $id = array_key_exists($id_key,$channels_id_parsed) ? $channels_id_parsed[$id_key] : 1000 + $i;
	    
            $channel =
                new DemoChannel(
                    $id,
                    $caption,
                    self::get_icon_path($id),
                    $media_url,
                    -1,
                    0,
                    self::get_future_epg_days($id));

            $this->channels->put($channel);
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////

    public function get_day_epg_iterator($channel_id, $day_start_ts, &$plugin_cookies)
    { 
    
    if ($channel_id >= 1000) 
	return array();
    
    $epg_date = date("Y-m-d", $day_start_ts);
    $epg = array();

    if (file_exists("/tmp/channel_".$channel_id."_".$day_start_ts)) {
	$doc = file_get_contents("/tmp/channel_".$channel_id."_".$day_start_ts);
	$epg = unserialize($doc);
    }
    else {
	try {
            $doc = HD::http_get_document(sprintf(DemoConfig::EPG_URL_FORMAT, $channel_id, $epg_date));
	}
	catch (Exception $e) {
	    hd_print("Can't fetch EPG ID:$id DATE:$epg_date");
	    return array();
	}
	
        $doc = iconv('WINDOWS-1251', 'UTF-8', $doc);

	$patterns = array("/<div class=\"desc\">/", "/<div class=\"onair\">/", "/<div class=\"pasttime\">/", "/<div class=\"time\">/", "/<br><br>/", "/<br>/", "/&nbsp;/");
        $replace = array("|", "\n", "\n", "\n", ". ", ". ", "");

	$doc = strip_tags(preg_replace($patterns, $replace, $doc));

        preg_match_all("/([0-2][0-9]:[0-5][0-9])([^\n]+)\n/", $doc, $matches);

	$last_time = 0;
	
        foreach ($matches[1] as $key => $time) {
	    $str = preg_split("/\|/", $matches[2][$key], 2);
	    $name = $str[0];
	    $desc = array_key_exists(1, $str) ? $str[1] : "";
	    $u_time = strtotime("$epg_date $time EEST");
	    $last_time = ($u_time < $last_time) ? $u_time + 86400 : $u_time;
	    $epg[$last_time]["name"] = $name;
	    $epg[$last_time]["desc"] = $desc;
	    }
	file_put_contents("/tmp/channel_".$channel_id."_".$day_start_ts, serialize($epg));
	}
	$epg_result = array();

	ksort($epg, SORT_NUMERIC);

	foreach ($epg as $time => $value) {
	    $epg_result[] =
                new DefaultEpgItem(
                    strval($value["name"]),
                    strval($value["desc"]),
                    intval($time),
                    intval(-1));
	}
	
	return
            new EpgIterator(
                $epg_result,
                $day_start_ts,
                $day_start_ts + 100400);
    }
}

///////////////////////////////////////////////////////////////////////////
?>
