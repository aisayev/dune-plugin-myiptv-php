<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/hashed_array.php';
require_once 'lib/tv/abstract_tv.php';
require_once 'lib/tv/default_epg_item.php';

require_once 'myiptv_channel.php';

///////////////////////////////////////////////////////////////////////////

class DemoM3uTv extends AbstractTv
{
    public function __construct()
    {
        parent::__construct(
            AbstractTv::MODE_CHANNELS_N_TO_M,
            DemoConfig::TV_FAVORITES_SUPPORTED,
            false);
    }

    public function get_fav_icon_url()
    {
        return DemoConfig::FAV_CHANNEL_GROUP_ICON_PATH;
    }

    public function get_tv_stream_url($playback_url, &$plugin_cookies)
    {
	if ($plugin_cookies->use_proxy == 'yes') 
	    $url = str_replace('udp://@', 'http://ts://'.$plugin_cookies->proxy_ip.':'.$plugin_cookies->proxy_port.'/udp/', $playback_url);
	
	if (substr(strtolower($playback_url), 0, 12) == 'http://ts://')
	    $url = $playback_url;
	else if (substr(strtolower($playback_url), 0, 12) == 'http://ts//')
	    $url = $playback_url;
	else if (substr(strtolower($playback_url), 0, 13) == 'http://mp4://')
	     $url = $playback_url;
	else if (substr(strtolower($playback_url), 0, 13) == 'http://mp4//')
	     $url = $playback_url;
	else if (substr(strtolower($playback_url), 0, 7) == 'http://')
	     $url = str_replace('http://', 'http://ts://', $playback_url);
	else 
	     $url = $playback_url;
	
	return $url;
    }


    public function parse_playlist($file) 
    {
	$path_parts = pathinfo($file);		
	if ($path_parts['extension'] == 'm3u')
		return self::parse_m3u($file);
	else if ($path_parts['extension'] == 'xspf')
		return self::parse_xspf($file);
	else {
		hd_print("Unknown extension: $file");
		return array();
	}
    }
	

    public function parse_m3u($m3u_file)
    {
	$playlist = array();

	if (!($m3u_lines = file($m3u_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))) {
		hd_print("Error opening $m3u_file");
		return $playlist;
	}
	
	$caption = ''; 	$url = ''; $logo = ''; 	$id = ''; $epg_shift = 0; $group_title = ''; $i = 0;

	foreach ($m3u_lines as $line) {
		$line = trim($line);	
	 	if (preg_match('/#EXTM3U/', strtoupper($line), $matches))
			continue;
		
		if (preg_match('/^#EXTINF:[^,]*,(.+)$/', $line, $matches)) {
			$caption = trim($matches[1]);

			if (preg_match('/^#EXTINF:.*logo=([^ ^,]+)/', $line, $matches)) {
			    $logo = preg_replace('/\"/', '', $matches[1]);			
			}
			
			if (preg_match('/^#EXTINF:.*id=([^ ^,]+)/', $line, $matches)) {
			    $id = preg_replace('/\"/', '', $matches[1]);			
			}
			
			if (preg_match('/^#EXTINF:.*epg_shift=([^ ^,]+)/', $line, $matches)) {
			    $epg_shift = preg_replace('/\"/', '', $matches[1]);			
			}
			continue;
		}
		$url = $line;
		$playlist[$i]['url'] = $url;
		$playlist[$i]['caption'] = ($caption == '') ? $url : $caption;		
		$playlist[$i]['logo'] = $logo;		
		$playlist[$i]['id'] = substr(trim($id), 6);
		$playlist[$i]['epg_shift'] = ($epg_shift == '') ? 0 : floatval($epg_shift);
		$playlist[$i]['epg_shift'] = (($playlist[$i]['epg_shift'] < -24) || ($playlist[$i]['epg_shift'] < -24)) ? 0 : $playlist[$i]['epg_shift'] + 24;
		$caption = '';
		$logo = '';
		$id = '';
		$i++;
		$epg_shift = 0;
		$group_title = '';
	}

    	return $playlist;

     }

    public function parse_xspf($xspf_file)
    {
    	libxml_use_internal_errors(true);

	$i = 0;	$playlist = array();
	$caption = ''; $logo = ''; $id = ''; $epg_shift = 0; $group_title = '';

	if (!($test = simplexml_load_string(file_get_contents($xspf_file)))) {
		hd_print("Error parsing $xspf_file");
		return $playlist;
	}

	else {
	
	foreach ($test->trackList->children() as $track) {
	    $caption = trim($track->title);
	    $url = trim($track->location);
	    $id_t = $track->extension->xpath('myiptv:id');
	    $id = isset($id_t[0]) ? substr(trim($id_t[0]), 6) : ''; 
	    $epg_shift_t = $track->extension->xpath('myiptv:epg_shift');
	    $epg_shift = isset($epg_shift_t[0]) ? floatval(trim($epg_shift_t[0])) : 0; 
	    $logo_t = $track->extension->xpath('myiptv:logo');
	    $logo = isset($logo_t[0]) ? trim($logo_t[0]) : ''; 
	    $playlist[$i]['url'] = $url;
	    $playlist[$i]['caption'] = ($caption == '') ? $url : $caption;		
	    $playlist[$i]['logo'] = $logo;		
	    $playlist[$i]['id'] = substr(trim($id), 6);
	    $playlist[$i]['epg_shift'] = ($epg_shift == '') ? 0 : floatval($epg_shift);
	    $playlist[$i]['epg_shift'] = (($playlist[$i]['epg_shift'] < -24) || ($playlist[$i]['epg_shift'] < -24)) ? 0 : $playlist[$i]['epg_shift'] + 24;
	    $caption = ''; $logo = ''; 	$id = ''; $epg_shift = 0; $group_title = '';
	    $i++;
	}
	return $playlist;
	}
    }


    ///////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////

    public function folder_entered(MediaURL $media_url, &$plugin_cookies) {
	if ($media_url->get_raw_string() == 'tv_group_list')
                $this->load_channels($plugin_cookies);            
    }

    private static function get_icon_path($channel_id)
    { 
	$channel_id = ($channel_id < 1000) ? $channel_id : 0;
	return sprintf(DemoConfig::M3U_ICON_FILE_URL_FORMAT, $channel_id); 
    }

    private static function get_future_epg_days($channel_id)
    { 
	$days = ($channel_id < 1000) ? 1 : 0;
	return $days;
    }

    protected function load_channels(&$plugin_cookies)
    {
        $this->channels = new HashedArray();
        $this->groups = new HashedArray();

        if ($this->is_favorites_supported())
        {
            $this->groups->put(
                new FavoritesGroup(
                    $this,
                    '__favorites',
                    DemoConfig::FAV_CHANNEL_GROUP_CAPTION,
                    DemoConfig::FAV_CHANNEL_GROUP_ICON_PATH));
        }

        $all_channels_group = 
            new AllChannelsGroup(
                $this,
                DemoConfig::ALL_CHANNEL_GROUP_CAPTION,
                DemoConfig::ALL_CHANNEL_GROUP_ICON_PATH);

        $this->groups->put($all_channels_group);

	$out_lines = "";
	$channels_id_parsed = array();
	$m3u_lines = array();
	
	  
	try {
		$doc = HD::http_get_document(DemoConfig::M3U_ID_FILE_URL);
	}
	catch (Exception $e) {
		hd_print("Can't fetch myiptv_chennels_id, local copy used.");		
		$doc = file_get_contents(dirname(__FILE__).'/data/myiptv_channels_id');
	}
	    
    	$channels_id_parsed = unserialize($doc);

        $m3u = isset($plugin_cookies->m3u) ? $plugin_cookies->m3u : '';

	$m3u_type = isset($plugin_cookies->m3u_type) ?
            $plugin_cookies->m3u_type : '1';
	
	if (($m3u_type == 3) && ($m3u == ''))
	    $m3u_type = 1;

	$m3u_dir = isset($plugin_cookies->m3u_dir) ?
            $plugin_cookies->m3u_dir : '/D';

	$m3u_files = array();
	

	if ($m3u_type == 1) {
		foreach (glob('{'.dirname(__FILE__).'/playlists/*.xspf,'.dirname(__FILE__).'/playlists/*.m3u}', GLOB_BRACE) as $file) 
    			if (is_file($file)) $m3u_files[]=$file;
	}
	else if ($m3u_type == 2) {
		foreach (glob('{'.$m3u_dir.'/*.m3u,'.$m3u_dir.'/*.xspf}', GLOB_BRACE) as $file) 
    			if (is_file($file)) $m3u_files[]=$file;
	}
	else 
		$m3u_files[]=$m3u;

	$gid = 0;
	foreach ($m3u_files as $m3u_file) {
		$path_parts = pathinfo($m3u_file);		
		$gname = $path_parts['filename'];
		$this->groups->put(
	                new DefaultGroup(
	                    strval($gid),
	                    strval($gname),
	                    strval('gui_skin://small_icons/tv.aai')));
		$gid++;
	}

	reset($m3u_files);

	$gid = 0; 

	foreach ($m3u_files as $m3u_file) {
	 $i = 0;
	 foreach (self::parse_playlist($m3u_file) as $playlist_line) {
	    $caption = $playlist_line['caption']; 
            $media_url = $playlist_line['url']; 

            $id_key = md5(strtolower(str_replace(array("\r", "\n", "\"", " "), '', $caption)));
            if ($playlist_line['id'] == '')
	    	$id = array_key_exists($id_key,$channels_id_parsed) ? $channels_id_parsed[$id_key] : 1000 + $i;
	    else
		$id = $playlist_line['id'];
		
	    $cid = $gid."_".$playlist_line['epg_shift']."_".$id;
	    $logo = ($playlist_line['logo'] == '') ? self::get_icon_path($id) : $playlist_line['logo'];

            $channel =
                new DemoChannel(
                    $cid,
                    $caption,
                    $logo,
                    $media_url,
                    -1,
                    0,
                    self::get_future_epg_days($id));

	    $this->channels->put($channel);

   	    $group = $this->groups->get($gid);
	    $channel->add_group($group);
            $group->add_channel($channel);
	    $i++;
	  }
	$gid++;        
	}
    }

    ///////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////

    public function get_day_epg_iterator($channel_id, $day_start_ts, &$plugin_cookies)
    { 
    
    list($garb, $epg_shift_pl, $channel_id) = preg_split('/_/', $channel_id);

    if ($channel_id >= 1000) 
	return array();
    
    $epg_shift = isset($plugin_cookies->epg_shift) ? $plugin_cookies->epg_shift : '0';
    $epg_shift += $epg_shift_pl - 24;
    hd_print($epg_shift);
    $epg_date = date("Y-m-d", $day_start_ts);
    $epg = array();

    if (file_exists("/tmp/channel_".$channel_id."_".$day_start_ts)) {
	$doc = file_get_contents("/tmp/channel_".$channel_id."_".$day_start_ts);
	$epg = unserialize($doc);
    }
    else {
	try {
            $doc = HD::http_get_document(sprintf(DemoConfig::EPG_URL_FORMAT, $channel_id, $epg_date));
	}
	catch (Exception $e) {
	    hd_print("Can't fetch EPG ID:$id DATE:$epg_date");
	    return array();
	}
	
        $doc = iconv('WINDOWS-1251', 'UTF-8', $doc);

	$patterns = array("/<div class=\"desc\">/", "/<div class=\"onair\">/", "/<div class=\"pasttime\">/", "/<div class=\"time\">/", "/<br><br>/", "/<br>/", "/&nbsp;/");
        $replace = array("|", "\n", "\n", "\n", ". ", ". ", "");

	$doc = strip_tags(preg_replace($patterns, $replace, $doc));

        preg_match_all("/([0-2][0-9]:[0-5][0-9])([^\n]+)\n/", $doc, $matches);

	$last_time = 0;
	
        foreach ($matches[1] as $key => $time) {
	    $str = preg_split("/\|/", $matches[2][$key], 2);
	    $name = $str[0];
	    $desc = array_key_exists(1, $str) ? $str[1] : "";
	    $u_time = strtotime("$epg_date $time EEST");
	    $last_time = ($u_time < $last_time) ? $u_time + 86400  : $u_time ;
	    $epg[$last_time]["name"] = $name;
	    $epg[$last_time]["desc"] = $desc;
	    }
	file_put_contents("/tmp/channel_".$channel_id."_".$day_start_ts, serialize($epg));
	}
	$epg_result = array();

	ksort($epg, SORT_NUMERIC);

	foreach ($epg as $time => $value) {
	    $epg_result[] =
                new DefaultEpgItem(
                    strval($value["name"]),
                    strval($value["desc"]),
                    intval($time + $epg_shift),
                    intval(-1));
	}
	
	return
            new EpgIterator(
                $epg_result,
                $day_start_ts,
                $day_start_ts + 100400);
    }
}

///////////////////////////////////////////////////////////////////////////
?>
